# Aurelia Heights Academy — Premium School Website Template

A reusable, premium marketing website for schools and educational institutions.
This repository ships with one fully-built demo school (**Aurelia Heights
Academy**, fictional). It is architected so a developer can rebrand it for a
new client without a redesign — only configuration and content changes.

```
MASTER TEMPLATE → change branding + content → SCHOOL A → duplicate → SCHOOL B
```

See **`DESIGN_SYSTEM.md`** for the full visual language (tokens, type,
color, component guidelines) and the pre-ship QA checklist. This file
covers file structure and the rebrand checklist.

---

## Stack

Plain HTML5 / CSS3 / vanilla JavaScript. No build step, no framework, no
database. Deploys as static files to Vercel, Netlify, GitHub Pages, or any
static host.

## File structure

```
school-template/
├── index.html            Homepage (single-page narrative — hero through footer)
├── about.html             Inner page — story, vision/mission/values, leadership
├── academics.html         Inner page — philosophy, programs, curriculum, support
├── admissions.html        Inner page — process, requirements, dates, fees, FAQ
├── campus-life.html       Inner page — student experience, photo mosaic, facilities
├── news.html              Inner page — featured story, filterable news grid
├── article-science-exhibition.html   Demo article page (the reusable article layout)
├── gallery.html           Inner page — filterable full gallery + lightbox
├── contact.html           Inner page — contact info, form, location
├── css/
│   ├── variables.css      ★ DESIGN TOKENS — brand colors, type, spacing
│   ├── base.css            Resets, typography roles, buttons, utilities
│   ├── components.css      Homepage section styles
│   ├── inner-pages.css     Inner-page-only components (hero, breadcrumbs,
│   │                        leader cards, timeline, FAQ, contact form,
│   │                        filter tabs, featured story, article layout)
│   └── responsive.css      Breakpoint overrides (tablet / phone / small phone)
├── js/
│   ├── config.js           ★ CONTENT SOURCE — school identity & contact data
│   ├── main.js              Reveal-on-scroll, stat counters, config sync, back-to-top
│   ├── navigation.js        Mobile menu, nav scroll state, scrollspy
│   ├── gallery.js           Lightbox (filter-aware — skips hidden items)
│   ├── gallery-filter.js    Category filter tabs (Gallery + News pages)
│   └── contact-form.js      Contact page form validation + mailto handoff
├── assets/
│   ├── images/              Photography goes here
│   ├── icons/                Any additional icon assets
│   └── logo/                 Crest / logo / favicon
├── README.md
└── DESIGN_SYSTEM.md
```

### Inner-page status

All seven inner pages are built: **About, Academics, Admissions, Campus
Life, News, Gallery, Contact** — plus one demo article page
(`article-science-exhibition.html`) demonstrating the reusable article
layout. Every nav link across every page points to a real file; there are
no homepage-anchor placeholders left in the global nav.

**Known content-quality shortcut, disclosed rather than hidden:** the photo
mosaic on `campus-life.html` reuses most of the same captions/placeholder
images as the homepage's own Campus Life section (only one tile was
swapped). A production build should give the inner page its own distinct
photo selection rather than repeating the homepage's teaser almost
verbatim.

**Only one article page exists.** The News page's Featured Story links to
it for real; the six News Grid cards below it deliberately have no "Read
more" link, since there's no article behind them yet — consistent with how
dead links were handled elsewhere in this project (see Stage 3.5 notes):
no affordance is shown unless it actually goes somewhere.

### How pages share the nav and footer

There's no templating engine (see "Stack" above), so the nav and footer
markup is duplicated at the top/bottom of every HTML file rather than
included from one source. Keep them in sync by hand when editing either —
if you change the nav or footer on one page, copy the same change to the
other three. Nav hrefs follow one rule throughout: a page that exists gets
a bare filename (`about.html`), a homepage section that doesn't have its
own page yet gets `index.html#section-id`. This lets every page share
identical nav markup with correctly-working links regardless of how deep
in the site the visitor currently is.

---

## Rebranding for a new school — where everything lives

| What to change | Where |
|---|---|
| **Brand colors** (primary / accent / secondary) | `css/variables.css`, top of `:root` — 3 HSL triads control the entire palette |
| **Typography** | `css/variables.css` → `--font-display` / `--font-body` / `--font-mono`, plus the Google Fonts `<link>` in `index.html <head>` |
| **School name, tagline, founding year, crest initials** | `js/config.js` → `identity` (also update the two inline SVG crests in `index.html`: nav and footer, and hardcoded copy in the hero `<h1>` / meta tags) |
| **Phone, WhatsApp, email, address, hours** | `js/config.js` → `contact` (auto-synced into every `tel:` / `mailto:` / WhatsApp link by `main.js`; update the visible address/hours text directly in the Contact section of `index.html`) |
| **Social links** | `js/config.js` → `social`, and the `href`s in the footer social icons in `index.html` |
| **Statistics (ledger)** | The four `.ledger__item` blocks in `index.html` — update `data-counter` values and labels |
| **Leadership welcome** | The "About" section in `index.html` — portrait, quote, name, role |
| **Who We Are (school introduction)** | The `#who-we-are` section in `index.html` — heading, body copy, three `.intro__point` items |
| **Why Choose Us (4 values)** | The four `.value-card` articles in `index.html` |
| **Academic programs** | The `.program-row` list in `index.html` — add, remove, or reorder rows freely (Roman numerals renumber by hand since the sequence is meaningful, not decorative) |
| **Academic differentiator (how we teach)** | The six `.differentiator` blocks in `index.html` |
| **Campus life photography grid** | The `.campus-tile` blocks in `index.html` — tags and captions |
| **Facilities** | The `.facility-card` articles in the `.facilities-strip` in `index.html` |
| **Achievements / track record** | The `.achievement-row` blocks in `index.html` |
| **News & events** | The `.news-card` articles in `index.html` |
| **Gallery images** | The `.gallery-item` blocks in `index.html` |
| **Testimonials** | The `.testimonial-card` articles in `index.html` |
| **Structured data** | The `application/ld+json` block in the `<head>` of `index.html` — keep in sync with `config.js` and the visible contact/address content |
| **About page content** | `about.html` — school story, vision/mission/values chips, philosophy, headteacher quote, three `.leader-card` bios |
| **Admissions process/requirements/dates/FAQ** | `admissions.html` — `.timeline-step` blocks, `.requirements-list` items, `.achievement-row` date rows, `<details>` FAQ items |
| **Fees** | `admissions.html` `#fees` — deliberately shows no invented figures; replace the "Contact admissions" placeholder cells with real figures when the school provides them, and remove the sample-data notice once real numbers are in place |
| **Contact form destination email** | The `mailto:` address is hardcoded in `js/contact-form.js` — update it alongside `config.js` → `contact.email` |
| **Academics: curriculum subjects** | `academics.html` `#curriculum` — seven `<details>` accordion items |
| **Campus Life mosaic + facilities** | `campus-life.html` — `.campus-tile` blocks and `.facility-card` filmstrip (same pattern as the homepage's own sections) |
| **News categories, cards, filters** | `news.html` — `.news-card` articles carry `data-category`; add/remove `.filter-tab` buttons in the same section to match |
| **Gallery categories, images, filters** | `gallery.html` — `.gallery-item` blocks carry `data-category`; keep filter tabs and item categories in sync |
| **Article template** | `article-science-exhibition.html` — duplicate this file for each new article; update the title, meta tags, breadcrumb, article body, and its entry in `news.html`'s Featured Story or grid |
| **Logo / favicon** | `assets/logo/` — replace `favicon.svg` and the inline crest SVGs |
| **Photography** | `assets/images/` — see "Images" below |
| **Page title, meta description, Open Graph tags** | `<head>` of `index.html` |

`js/config.js` is written as the canonical content reference for a rebrand —
it documents every piece of school-specific data in one object — and it also
drives the handful of details that appear in more than one place (contact
links, footer copyright name, document title), synced automatically at
runtime by `main.js`. For SEO and no-JS reliability, the bulk of the on-page
copy is written directly and semantically into `index.html` rather than
injected by JavaScript; when rebranding, treat `config.js` as your checklist
and mirror each value into the corresponding markup listed above.

### Images

No stock photography ships with this template. Every image slot is a
generated placeholder (a `.ph` element — directional gradient, a faint
diagonal texture, and a large low-opacity "AH" crest monogram watermark) so
the layout, spacing, and composition are correct out of the box and the
page never shows an obviously empty box. To go live:

1. Drop real photos into `assets/images/` (see `js/config.js` → `images`
   for the checklist of what's needed and where each one is used).
2. Replace the relevant `<div class="ph ...">` with an `<img src="..." alt="...">`,
   keeping the same wrapping element and class names on the parent so spacing
   and aspect ratios are preserved.
3. Keep `alt` text descriptive — placeholders already carry the correct
   `aria-label` copy to reuse.

If you rebrand to a school with different initials, update the "AH"
watermark in `css/components.css` (`.ph::before`) alongside the two inline
crest SVGs in `index.html` (nav + footer) — all three should always match.

---

## Design system notes

- **Palette**: ink navy (`--primary`), brass gold (`--accent`), warm paper
  background, sage green used sparingly for tags and WhatsApp. Defined as
  HSL triads in `variables.css` so a new brand is a 6-number change.
- **Type**: Fraunces (display serif) for headings, Inter for body copy, IBM
  Plex Mono for eyebrows/labels/statistics — deliberately not a generic
  sans-only system, to read as an institutional prospectus rather than a
  SaaS landing page.
- **Signature device**: the site is composed like a premium admissions
  prospectus rather than a stack of generic cards — a ledger-style stats
  bar, a masthead hero with a vertical "Est." ribbon, and Roman numerals
  used only where the content is genuinely sequential (the four academic
  stages). This is deliberate; don't add numbered badges elsewhere.

## Accessibility

Semantic landmarks (`header`, `nav`, `main`, `footer`), one `<h1>` per page,
logical heading order, visible focus states on every interactive element,
`aria-label`s on icon-only controls, an accessible lightbox (focus trap,
Escape to close, arrow-key navigation), a skip-to-content link, and full
`prefers-reduced-motion` support (reveal animations and counters are
disabled/instant).

## Performance

No JS framework, no icon font (inline SVG only), no external libraries
beyond Google Fonts. `IntersectionObserver` gates scroll reveal and counters
so nothing animates off-screen. Add real images with explicit `width`/
`height` (or `aspect-ratio` CSS, already set on every image slot) to avoid
layout shift, and serve them via `loading="lazy"` for anything below the
fold.

## What this template intentionally does not include

Per product scope: no login system, no database, no payments, no chat
widget, no CMS backend. This is a marketing/admissions website. Those are
candidates for separate premium add-on packages.
